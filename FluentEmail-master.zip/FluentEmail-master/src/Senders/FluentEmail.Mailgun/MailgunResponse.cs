﻿namespace FluentEmail.Mailgun
{
    public class MailgunResponse
    {
        public string Id { get; set; }
        public string Message { get; set; }
    }
}
