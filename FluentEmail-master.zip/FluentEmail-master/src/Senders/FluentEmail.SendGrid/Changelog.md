﻿## 2.6.0
 - Fixed #129 - Update Sendgrid dependancy
## 2.0.2  
 - Fixed #64 - Binary attachments weren't being encoded correctly
